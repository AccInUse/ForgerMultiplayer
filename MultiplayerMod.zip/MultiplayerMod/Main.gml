#define Main
// Initialize our networking variables on startup
global.isHost = false;
global.connected = false;
global.tcpPort = 6511;

// We need a variable to store the socket of whoever we are talking to
global.partnerSocket = -4; 

audio_play_sound(sndCoin1, 1, false);

#define OnStep
// 1. BECOME THE HOST (Press F2)
if (keyboard_check_pressed(vk_f2)) {
    if (!global.isHost && !global.connected) {
        // network_create_server(type, port, max_clients)
        var _server = network_create_server(network_socket_tcp, global.tcpPort, 1);
        
        if (_server >= 0) {
            global.isHost = true;
            audio_play_sound(sndLevelUp, 1, false); // Happy sound for success
        } else {
            audio_play_sound(sndError, 1, false); // Sad sound for failure
        }
    }
}

// 2. BECOME THE CLIENT (Press F3)
if (keyboard_check_pressed(vk_f3)) {
    if (!global.isHost && !global.connected) {
        global.partnerSocket = network_create_socket(network_socket_tcp);
        
        // Connect to localhost on the same port
        var _connection = network_connect(global.partnerSocket, "127.0.0.1", global.tcpPort);
        
        if (_connection >= 0) {
            global.connected = true;
            audio_play_sound(sndLevelUp, 1, false); 
        } else {
            audio_play_sound(sndError, 1, false);
        }
    }
}

// 3. SEND A TEST PACKET (Press F4)
if (keyboard_check_pressed(vk_f4)) {
    if (global.connected) {
        // Create a 1-byte growable buffer
        var _packet = buffer_create(1, buffer_grow, 1);
        
        // Write our command ID (We will just use the number 99 for our ping)
        buffer_write(_packet, buffer_u8, 99); 
        
        // Send it to the partner socket
        network_send_packet(global.partnerSocket, _packet, buffer_tell(_packet));
        
        // Always delete the buffer afterwards to prevent memory leaks!
        buffer_delete(_packet);
    }
}

#define OnNetworkAsync
// This hook automatically triggers ANY time data hits your network port
var _type = async_load[? "type"];

// IF WE ARE THE HOST, WE NEED TO CATCH THE CLIENT CONNECTING
if (global.isHost) {
    if (_type == network_type_connect) {
        // Save the socket ID of the client who just joined so we can talk back to them
        global.partnerSocket = async_load[? "socket"];
        global.connected = true;
        
        // Play a sound so the Host knows someone joined
        audio_play_sound(sndQuestComplete, 1, false); 
    }
}

// IF ANY DATA PACKETS ARRIVE
if (_type == network_type_data) {
    var _buffer = async_load[? "buffer"];
    
    // Read the first piece of data to see what the command is
    var _command = buffer_read(_buffer, buffer_u8);
    
    // If the command is our test ping (99)
    if (_command == 99) {
        // The packet was received! Play a sound and jump!
        audio_play_sound(sndCoin1, 1, false);
        if (instance_exists(objPlayer)) {
            objPlayer.y -= 20; 
        }
    }
}