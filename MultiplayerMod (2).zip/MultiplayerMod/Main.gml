#define Main
global.isHost = false;
global.connected = false;
global.tcpPort = 6511;
global.partnerSocket = -4; 

global.partnerX = -4;
global.partnerY = -4;
global.partnerSprite = -4;
global.partnerFrame = 0;
global.partnerFacing = 1;
global.partnerTool = -4; 
global.partnerAngle = 0; 

// --- NEW SYNC VARIABLES ---
global.ignoreNetworkSync = false;
global.trackedEntity = noone;
global.trackedX = 0;
global.trackedY = 0;

audio_play_sound(sndCoin1, 1, false);


#define OnStep
if (keyboard_check_pressed(vk_f2)) {
    if (!global.isHost && !global.connected) {
        var _server = network_create_server(network_socket_tcp, global.tcpPort, 1);
        if (_server >= 0) {
            global.isHost = true;
            audio_play_sound(sndLevelUp, 1, false);
        }
    }
}

if (keyboard_check_pressed(vk_f3)) {
    if (!global.isHost && !global.connected) {
        global.partnerSocket = network_create_socket(network_socket_tcp);
        var _connection = network_connect(global.partnerSocket, "127.0.0.1", global.tcpPort);
        if (_connection >= 0) {
            global.connected = true;
            audio_play_sound(sndLevelUp, 1, false); 
        }
    }
}

// ==========================================
// PLAYER SYNC & MULTI-RESOURCE WORLD RADAR
// ==========================================
if (global.connected && instance_exists(objPlayer)) {
    
    // --- 1. SEND PLAYER MOVEMENT ---
    var _packet = buffer_create(1, buffer_grow, 1);
    buffer_write(_packet, buffer_u8, 10); 
    buffer_write(_packet, buffer_s32, floor(objPlayer.x));
    buffer_write(_packet, buffer_s32, floor(objPlayer.y));
    buffer_write(_packet, buffer_s32, objPlayer.sprite_index);
    buffer_write(_packet, buffer_f32, objPlayer.image_index);
    buffer_write(_packet, buffer_s8, objPlayer.facing);
    buffer_write(_packet, buffer_u16, floor(objPlayer.image_angle));
    
    var _tool = ToolSelected();
    var _toolID = (string_digits(string(_tool)) != "") ? real(_tool) : -4;
    buffer_write(_packet, buffer_s16, _toolID);
    
    network_send_packet(global.partnerSocket, _packet, buffer_tell(_packet));
    buffer_delete(_packet);


    // --- 2. WORLD RADAR (DESTROY SYNC) ---
    if (!global.ignoreNetworkSync) {
        
        // A. Check if the specific resource we were watching just got destroyed
        if (global.trackedEntity != noone && !instance_exists(global.trackedEntity)) {
            
            // CHECKPOINT 1: Sender detected destruction! (Plays a Coin sound)
            audio_play_sound(sndCoin1, 1, false); 
            
            var _destroyPacket = buffer_create(1, buffer_grow, 1);
            buffer_write(_destroyPacket, buffer_u8, 20);
            buffer_write(_destroyPacket, buffer_s32, floor(global.trackedX));
            buffer_write(_destroyPacket, buffer_s32, floor(global.trackedY));
            
            network_send_packet(global.partnerSocket, _destroyPacket, buffer_tell(_destroyPacket));
            buffer_delete(_destroyPacket);
            
            // Clear the tracker so it doesn't fire twice
            global.trackedEntity = noone;
        }
        
        // B. Lock onto the closest resource (Rock, Tree, or Iron Deposit) near the mouse cursor
        var _nearest = noone;
        var _minDist = 40;
        
        // Check Rocks
        var _r = instance_nearest(mouse_x, mouse_y, objRock);
        if (_r != noone) {
            var _d = point_distance(mouse_x, mouse_y, _r.x, _r.y);
            if (_d < _minDist) {
                _minDist = _d;
                _nearest = _r;
            }
        }
        
        // Check Trees
        var _t = instance_nearest(mouse_x, mouse_y, objTree);
        if (_t != noone) {
            var _d = point_distance(mouse_x, mouse_y, _t.x, _t.y);
            if (_d < _minDist) {
                _minDist = _d;
                _nearest = _t;
            }
        }
        
        // Check Iron Deposits safely
        var _ironIndex = asset_get_index("objIronDeposit");
        if (_ironIndex != -1) {
            var _i = instance_nearest(mouse_x, mouse_y, _ironIndex);
            if (_i != noone) {
                var _d = point_distance(mouse_x, mouse_y, _i.x, _i.y);
                if (_d < _minDist) {
                    _minDist = _d;
                    _nearest = _i;
                }
            }
        }
        
        // Only track it if our mouse is actually hovering near it
        if (_nearest != noone) {
            global.trackedEntity = _nearest;
            global.trackedX = _nearest.x;
            global.trackedY = _nearest.y;
        } else {
            // If the mouse moves away, stop tracking
            global.trackedEntity = noone;
        }
    }
}


// ==========================================
// RECEIVER LOGIC
// ==========================================
#define OnNetworkAsync(async_load)
var _type = async_load[? "type"];

if (global.isHost) {
    if (_type == network_type_connect) {
        global.partnerSocket = async_load[? "socket"];
        global.connected = true;
        audio_play_sound(sndLevelUp, 1, false); 
    }
}

if (_type == network_type_data) {
    var _buffer = async_load[? "buffer"];
    var _command = buffer_read(_buffer, buffer_u8);
    
    // COMMAND 10: Player Position Sync
    if (_command == 10) {
        global.partnerX = buffer_read(_buffer, buffer_s32);
        global.partnerY = buffer_read(_buffer, buffer_s32);
        global.partnerSprite = buffer_read(_buffer, buffer_s32);
        global.partnerFrame = buffer_read(_buffer, buffer_f32);
        global.partnerFacing = buffer_read(_buffer, buffer_s8);
        global.partnerAngle = buffer_read(_buffer, buffer_u16);
        global.partnerTool = buffer_read(_buffer, buffer_s16);
    }
    
    // COMMAND 20: World Event - Destroy Object
    if (_command == 20) {
        
        // CHECKPOINT 2: Packet Received by Window 2! (Plays a Level Up sound)
        audio_play_sound(sndLevelUp, 1, false);
        
        var _targetX = buffer_read(_buffer, buffer_s32);
        var _targetY = buffer_read(_buffer, buffer_s32);
        
        var _inst = noone;
        var _minDist = 100;
        
        // Check Rocks
        var _r = instance_nearest(_targetX, _targetY, objRock);
        if (_r != noone) {
            var _d = point_distance(_targetX, _targetY, _r.x, _r.y);
            if (_d < _minDist) {
                _minDist = _d;
                _inst = _r;
            }
        }
        
        // Check Trees
        var _t = instance_nearest(_targetX, _targetY, objTree);
        if (_t != noone) {
            var _d = point_distance(_targetX, _targetY, _t.x, _t.y);
            if (_d < _minDist) {
                _minDist = _d;
                _inst = _t;
            }
        }
        
        // Check Iron Deposits safely
        var _ironIndex = asset_get_index("objIronDeposit");
        if (_ironIndex != -1) {
            var _i = instance_nearest(_targetX, _targetY, _ironIndex);
            if (_i != noone) {
                var _d = point_distance(_targetX, _targetY, _i.x, _i.y);
                if (_d < _minDist) {
                    _minDist = _d;
                    _inst = _i;
                }
            }
        }
        
        // Check within 100 pixels 
        if (_inst != noone) {
            
            // CHECKPOINT 3: Target Destroyed by Window 2! (Plays a Coin sound)
            audio_play_sound(sndCoin1, 1, false);
            
            global.ignoreNetworkSync = true; 
            instance_destroy(_inst);
            global.ignoreNetworkSync = false; 
        }
    }
}


#define OnDrawEnd
if (global.connected && global.partnerX != -4) {
    
    draw_sprite_ext(global.partnerSprite, global.partnerFrame, global.partnerX, global.partnerY, global.partnerFacing, 1, global.partnerAngle, c_white, 1);

    if (global.partnerTool != -4) {
        var _toolSprite = ItemGet(global.partnerTool, ItemData.Sprite);
        var _toolX = (global.partnerFacing == 1) ? (global.partnerX - 5) : (global.partnerX + 5);
        var _toolY = global.partnerY - 2;
        var _toolRotation;
        
        if (global.partnerTool >= 114 && global.partnerTool <= 129) {
            _toolRotation = (global.partnerFacing == 1) ? 90 : 0;
        } else {
            _toolRotation = 90 * global.partnerFacing;
        }
        
        draw_sprite_ext(_toolSprite, 0, _toolX, _toolY, 1, 1, _toolRotation, c_white, 1);
    }
}